__version__ = '2020.0'

from .openneuro import download  # noqa: F401
