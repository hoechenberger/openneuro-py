from setuptools import setup, find_packages
from openneuro import __version__

setup(packages=find_packages(),
      version=__version__)
